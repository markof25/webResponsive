function mostrarAmagar(id) {
    var desplegar = document.getElementById(id)

    //if (desplegar != " ") {
    //    desplegar.style.display = "none";
    //} else {
        //desplegar.style.display = "block";
    //}
	var val = desplegar.style.display;
	desplegar.style.display = (val == "none") ? "block" : "none";
}